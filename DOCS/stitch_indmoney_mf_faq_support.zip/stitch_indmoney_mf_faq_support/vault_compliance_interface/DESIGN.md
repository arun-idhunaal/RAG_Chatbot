---
name: Vault Compliance Interface
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393f'
  surface-container-lowest: '#0c0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#282a2f'
  surface-container-highest: '#33353a'
  on-surface: '#e2e2e9'
  on-surface-variant: '#d1c5ac'
  inverse-surface: '#e2e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#9a9078'
  outline-variant: '#4e4633'
  surface-tint: '#f0c110'
  primary: '#ffe5a0'
  on-primary: '#3d2f00'
  primary-container: '#f5c518'
  on-primary-container: '#695200'
  inverse-primary: '#745b00'
  secondary: '#3ce42f'
  on-secondary: '#003a00'
  secondary-container: '#00c705'
  on-secondary-container: '#004b00'
  tertiary: '#ffe4b1'
  on-tertiary: '#402d00'
  tertiary-container: '#ffc11e'
  on-tertiary-container: '#6e5100'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe08b'
  primary-fixed-dim: '#f0c110'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#584400'
  secondary-fixed: '#77ff62'
  secondary-fixed-dim: '#3ce42f'
  on-secondary-fixed: '#002200'
  on-secondary-fixed-variant: '#005300'
  tertiary-fixed: '#ffdfa0'
  tertiary-fixed-dim: '#fbbc00'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#111318'
  on-background: '#e2e2e9'
  surface-variant: '#33353a'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar-width: 300px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  stack-gap: 12px
---

## Brand & Style
The design system is centered on high-stakes financial compliance and trust. It utilizes a **Corporate Modern** aesthetic with **Minimalist** constraints to ensure the information remains the primary focus. The personality is authoritative, precise, and secure, designed to evoke a sense of institutional reliability.

Visual signatures include high-density information layouts, hairline borders, and a strict dark-mode color logic that minimizes eye strain during deep document review. The interface avoids all decorative elements, relying instead on systematic spacing and structural integrity to convey quality.

## Colors
The palette is dominated by deep, monochromatic tones to create a focused "command center" environment. 

- **Primary (Gold):** Reserved for high-value interactions, primary action buttons, and active indicators. Use with intent; it should never exceed 5% of the screen real estate.
- **Secondary (Trust Green):** Specifically for verified data points, successful compliance checks, and official status chips.
- **Tertiary (Amber):** Used for advisory warnings and policy-related refusals.
- **Surface Logic:** Backgrounds use `#0B0D12`. Main content containers use `#12141A`. Interactive or floating elements use `#171A22`.
- **Borders:** All borders are fixed at 1px thickness with a subtle 10% white opacity to define structure without adding visual noise.

## Typography
The system uses a single geometric sans-serif (Inter) to maintain a systematic, utilitarian feel. 

- **Headlines:** Use tight letter-spacing (-0.02em) to maintain a dense, professional appearance.
- **Body:** Prioritize readability with a 1.5x line-height ratio. 
- **Data Labels:** Use `label-sm` for table headers and metadata, always in uppercase with slight tracking to ensure legibility at small sizes.
- **Compliance Text:** Disclaimer text and legal footnotes should never drop below 11px to ensure accessibility and regulatory adherence.

## Layout & Spacing
The layout follows a **Fixed Grid** model for the sidebar and a **Fluid Content** area for the chat and data views.

- **Sidebar:** A persistent 300px sidebar on desktop provides navigation and context. It collapses into a bottom drawer or hamburger menu on mobile.
- **Chat Container:** Centrally aligned with a maximum width of 800px to maintain comfortable reading lines for long-form financial explanations.
- **Comparison Tables:** Allow for horizontal overflow on small screens with a persistent left-column freeze if data points exceed 3 columns.
- **Sticky Zones:** The header (for branding/navigation) and footer (for mandatory disclaimers) are fixed to ensure compliance information is always visible.

## Elevation & Depth
This design system avoids traditional drop shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0 (Background):** `#0B0D12` - The base canvas.
- **Level 1 (Cards/Sidebar):** `#12141A` with 1px border `rgba(255,255,255,0.08)`.
- **Level 2 (Modals/Popovers):** `#171A22` with a more pronounced 1px border `rgba(255,255,255,0.15)` and a very subtle, large-radius black shadow (0px 8px 32px rgba(0,0,0,0.4)).
- **Interactive States:** On hover, surfaces should slightly lighten or the border opacity should increase to 20% to signal interactivity.

## Shapes
The shape language is a mix of high-radius containers and full-pill interactive elements.

- **Cards & Containers:** 12px - 16px radius. This provides a modern, approachable feel while maintaining professional structure.
- **Chips & Hyperlink Pills:** 24px radius. Used for citations and tags to make them feel distinct from data containers.
- **Action Buttons:** 999px (Full Pill). This shape is reserved exclusively for "Send," "Export," or "Agree" actions to create a clear functional distinction from information cards.

## Components
- **Chat Bubbles:** 
    - *User:* Right-aligned, dark surface, minimal padding. 
    - *Assistant:* Left-aligned, elevated surface card (`#12141A`), 16px padding.
- **Citation Chips:** Styled as interactive pills with a leading icon (e.g., a document or link icon). On hover, the gold primary color should underline the text.
- **Comparison Tables:** Use `#12141A` for the container. Rows should have a 1px bottom border. Header rows should use `label-sm` typography with a subtle grey background tint.
- **Input Fields:** Bottom-aligned chat bar with a fixed height. Use a hairline border and a subtle `#171A22` fill. The "Send" button should be the primary gold color when text is present.
- **Compliance Banners:** Fixed to the bottom of the viewport. Use `label-sm` text with low-contrast coloring (60% white) to ensure it is present but not distracting from the core task.